-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Mar 07, 2020 at 10:12 PM
-- Server version: 10.1.34-MariaDB
-- PHP Version: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `skripsi_library`
--

-- --------------------------------------------------------

--
-- Table structure for table `arsip`
--

CREATE TABLE `arsip` (
  `idarsip` int(11) NOT NULL,
  `judul` varchar(256) NOT NULL,
  `tanggal_lulus` date NOT NULL,
  `nim` varchar(15) NOT NULL,
  `nama_lengkap` varchar(128) NOT NULL,
  `abstrak` text NOT NULL,
  `file` varchar(128) NOT NULL,
  `upload_at` date NOT NULL,
  `upload_by` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `dosen`
--

CREATE TABLE `dosen` (
  `iddosen` int(11) NOT NULL,
  `nip` varchar(25) NOT NULL,
  `nama_lengkap` varchar(128) NOT NULL,
  `tempat_lahir` varchar(128) NOT NULL,
  `tanggal_lahir` date NOT NULL,
  `jk` enum('L','P') NOT NULL,
  `telp` varchar(15) NOT NULL,
  `alamat` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dosen`
--

INSERT INTO `dosen` (`iddosen`, `nip`, `nama_lengkap`, `tempat_lahir`, `tanggal_lahir`, `jk`, `telp`, `alamat`) VALUES
(8, '19860926 201505 1 009', 'EKA SAPUTRA', 'BINTUNI', '1997-11-02', 'L', '092131231232', 'Jalan 8'),
(9, '19860926 201505 1 001', 'EKA SAPUTRA', 'BINTUNI', '1997-10-27', 'L', '092312349876', 'Jalan 1'),
(10, '19860926 201505 1 002', 'EKA SAPUTRA', 'BINTUNI', '1997-10-27', 'P', '092131231232', 'Jalan 2'),
(11, '19860926 201505 1 003', 'EKA SAPUTRA', 'BINTUNI', '1997-10-28', 'P', '092312349876', 'Jalan 3'),
(12, '19860926 201505 1 004', 'EKA SAPUTRA', 'BINTUNI', '1997-10-29', 'L', '092131231232', 'Jalan 4'),
(13, '19860926 201505 1 005', 'EKA SAPUTRA', 'BINTUNI', '1997-10-30', 'P', '092312349876', 'Jalan 5'),
(14, '19860926 201505 1 006', 'EKA SAPUTRA', 'BINTUNI', '1997-10-31', 'L', '092131231232', 'Jalan 6'),
(15, '19860926 201505 1 007', 'EKA SAPUTRA', 'BINTUNI', '1997-11-01', 'L', '092312349876', 'Jalan 7'),
(16, '19860926 201505 1 008', 'EKA SAPUTRA', 'BINTUNI', '1997-11-02', 'P', '092131231232', 'Jalan 8'),
(17, '19860926 201505 1 010', 'EKA SAPUTRA', 'BINTUNI', '1997-11-02', 'L', '', 'rumah saya');

-- --------------------------------------------------------

--
-- Table structure for table `mahasiswa`
--

CREATE TABLE `mahasiswa` (
  `idmahasiswa` int(11) NOT NULL,
  `nim` varchar(10) NOT NULL,
  `nama_lengkap` varchar(128) NOT NULL,
  `jk` enum('L','P') NOT NULL,
  `tempat_lahir` varchar(128) NOT NULL,
  `tanggal_lahir` date NOT NULL,
  `jenjang` varchar(5) NOT NULL,
  `program_studi` tinyint(4) NOT NULL COMMENT '1 = Teknik Informatika, 2 = Teknik Komputer'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mahasiswa`
--

INSERT INTO `mahasiswa` (`idmahasiswa`, `nim`, `nama_lengkap`, `jk`, `tempat_lahir`, `tanggal_lahir`, `jenjang`, `program_studi`) VALUES
(8, '201552002', 'EKA SAPUTRA', 'P', 'BINTUNI', '1997-10-28', 'S1', 1),
(9, '201552003', 'EKA SAPUTRA', 'L', 'BINTUNI', '1997-10-29', 'D3', 2),
(10, '201552004', 'EKA SAPUTRA', 'P', 'BINTUNI', '1997-10-30', 'S1', 1),
(11, '201552005', 'EKA SAPUTRA', 'L', 'BINTUNI', '1997-10-31', 'S1', 1),
(12, '201552006', 'EKA SAPUTRA', 'L', 'BINTUNI', '1997-11-01', 'D3', 2),
(13, '201552007', 'EKA SAPUTRA', 'P', 'BINTUNI', '1997-11-02', 'D3', 2);

-- --------------------------------------------------------

--
-- Table structure for table `publikasi`
--

CREATE TABLE `publikasi` (
  `idpublikasi` int(11) NOT NULL,
  `judul` varchar(256) NOT NULL,
  `tanggal_lulus` date NOT NULL,
  `nim` varchar(15) NOT NULL,
  `nama_lengkap` varchar(128) NOT NULL,
  `abstrak` text NOT NULL,
  `file` varchar(128) NOT NULL,
  `view` int(11) NOT NULL,
  `download` int(11) NOT NULL,
  `upload_at` date NOT NULL,
  `upload_by` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `publikasi`
--

INSERT INTO `publikasi` (`idpublikasi`, `judul`, `tanggal_lulus`, `nim`, `nama_lengkap`, `abstrak`, `file`, `view`, `download`, `upload_at`, `upload_by`) VALUES
(3, 'Sistem Informasi Skripsi', '2020-02-20', '201552002', 'EKA SAPUTRA', 'asfasfasfasfasfasf', '201552002-EKA SAPUTRA-20200203013206.pdf', 3, 1, '0000-00-00', 19),
(7, 'Laporan Tugas Akhir Eka Saputra', '2020-03-04', '201552003', 'EKA SAPUTRA', 'Generally, a hyperlink is used to link a PDF document to display in the browser. HTML anchor link is the easiest way to display a PDF file. But if you want to display PDF document on the web page, PDF file need to be embedded in HTML. The HTML <embed> tag is the best option to embed PDF document on the web page. In this tutorial, we will show you how to display PDF file in the web page using HTML <embed> tag.\r\n\r\nThe HTML <embed> tag defines a container to load external content. The following parameters can be specified in <embed> tag.\r\n\r\nsrc â€“ Specifies the path of the external file to embed.\r\ntype â€“ Specifies the media type of the embedded content.\r\nwidth â€“ Specifies the width of the embedded content.\r\nheight â€“ Specifies the height of the embedded content.\r\nEmbed PDF File in HTML\r\nUse the following code to embed PDF file in the HTML web page.\r\n\r\n<embed src=\"files/Brochure.pdf\" type=\"application/pdf\" width=\"100%\" height=\"600px\" />\r\nNow we will show how you can control the PDF document view on the web page. Using parameters in URL, you can specify exactly what to display and how to display PDF document.\r\n\r\nThe following parameters are commonly used to embed PDF file in HTML or open in the browser.\r\n\r\npage=pagenum â€“ Specifies a number (integer) of the page in the document. The documentâ€™s first page has a pagenum value of 1.\r\nzoom=scale â€“ Sets the zoom and scroll factors, using float or integer values. For example, a scale value of 100 indicates a zoom value of 100%.\r\nview=Fit â€“ Set the view of the displayed page.\r\nscrollbar=1|0 â€“ Turns scrollbars on or off.\r\ntoolbar=1|0 â€“ Turns the toolbar on or off.\r\nstatusbar=1|0 â€“ Turns the status bar on or off.\r\nnavpanes=1|0 â€“ Turns the navigation panes and tabs on or off.\r\nSpecifying Parameters in a URL\r\nYou can specify multiple parameters in URL. Each parameter should be separated with either an ampersand (&) or a pound (#) character. Actions are executed from left to right and later actions will override the previous actions.\r\n\r\nURL with parameters looks like the following.\r\n\r\nhttp://example.com/doc.pdf#Chapter5\r\nhttp://example.com/doc.pdf#page=5\r\nhttp://example.com/doc.pdf#page=3&zoom=200,250,100\r\nhttp://example.com/doc.pdf#zoom=100\r\nhttp://example.com/doc.pdf#page=72&view=fitH,100\r\nDisable and Hide Toolbar in PDF Web Viewer\r\nThis example shows how to hide or remove the toolbar, navpanes, and scrollbar of the PDF file opened in HTML <embed> using parameters in URL.\r\nUse the following code to embed PDF document in the web page and remove or hide toolbar of embedded PDF.\r\n\r\n<embed src=\"files/Brochure.pdf#toolbar=0&navpanes=0&scrollbar=0\" type=\"application/pdf\" width=\"100%\" height=\"600px\" />', '201552003-EKA SAPUTRA-20200204000920.pdf', 0, 0, '0000-00-00', 20);

-- --------------------------------------------------------

--
-- Table structure for table `skripsi`
--

CREATE TABLE `skripsi` (
  `idskripsi` int(11) NOT NULL,
  `judul` varchar(256) NOT NULL,
  `tanggal_lulus` date NOT NULL,
  `nim` varchar(15) NOT NULL,
  `nama_lengkap` varchar(128) NOT NULL,
  `abstrak` text NOT NULL,
  `file` varchar(128) NOT NULL,
  `upload_at` date NOT NULL,
  `upload_by` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `skripsi`
--

INSERT INTO `skripsi` (`idskripsi`, `judul`, `tanggal_lulus`, `nim`, `nama_lengkap`, `abstrak`, `file`, `upload_at`, `upload_by`) VALUES
(1, 'Sistem Informasi Skripsi', '2020-02-29', '201552005', 'EKA SAPUTRA', 'asdasdasd', '201552005-EKA SAPUTRA-20200307080914.pdf', '2020-03-07', 22);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `idusers` int(11) NOT NULL,
  `user_name` varchar(25) DEFAULT NULL,
  `user_password` varchar(128) DEFAULT NULL,
  `user_fullname` varchar(128) DEFAULT NULL,
  `user_telp` varchar(15) DEFAULT NULL,
  `user_type` enum('super_user','administrator','user','dosen','mahasiswa') DEFAULT NULL,
  `user_bio` text,
  `is_active` int(1) DEFAULT NULL,
  `is_block` int(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`idusers`, `user_name`, `user_password`, `user_fullname`, `user_telp`, `user_type`, `user_bio`, `is_active`, `is_block`) VALUES
(1, 'admin', '$2y$10$h6Mas3QjJTZgIfQH5jFiYOdsXKhzP0M08oVD.DXExrn.mA8RshOJa', 'SkripsiLibrary', '082248577297', 'super_user', 'Saya admin dengan akses super_user', 1, 0),
(19, '201552002', '$2y$10$vKTLitAHaBb6Vol/xSQNc.tu5ihazMs3vVyU/Kr1KWuIdt0/2L2bm', 'EKA SAPUTRA', '121312', 'mahasiswa', NULL, 1, 0),
(20, '201552003', '$2y$10$zgklSrDgxZFQ3c5lVOcAGOZ.HdqTDkNA8nueWANBGvElNCrM1.edW', 'EKA SAPUTRA', NULL, 'mahasiswa', NULL, 1, 0),
(21, '201552004', '$2y$10$ZOjLNMMEf3ZoAJSj6wvUd.sADentrLGxqHG.jTYGxq7t2dhgETeX2', 'EKA SAPUTRA', NULL, 'mahasiswa', NULL, 1, 0),
(22, '201552005', '$2y$10$39VaNVLXEs4z3G9iKjQVM.XNA50VaUq/t9p9s5fCesB2okTmpjuDW', 'EKA SAPUTRA', NULL, 'mahasiswa', NULL, 1, 0),
(23, '201552006', '$2y$10$lJjlEOu025H0tEbhIdwzB.Uz89T5esYz9A6lKdVOZd1ceUPIklyqa', 'EKA SAPUTRA', NULL, 'mahasiswa', NULL, 1, 0),
(24, '201552007', '$2y$10$J/axDd6G9cssXb3j/0GcOezHORWS3IhGQHB.lpwC0Vi7Lhqu/Uiru', 'EKA SAPUTRA', NULL, 'mahasiswa', NULL, 1, 0),
(30, '123', '$2y$10$ysYZ3NpkW/c.4rWwkKUpjOL4ZH9l0Vn4G3iDvYcB0lYXLGPb7N0LO', '123', '123', 'user', NULL, 1, 0),
(31, '12345', '$2y$10$0cvKK0SsN70dfbs5TKKddOMEhpIbManXb8hcj9H4wcMQXKvdiNN9W', '12345', '12345', 'administrator', NULL, 1, 0),
(62, '198609262015051009', '$2y$10$QQ0Ev7ltJdFGqlcxS0Vhi.4L0/wlZrPdscCCABUbfpS6iOBNcNOce', 'EKA SAPUTRA', NULL, 'dosen', NULL, 1, 0),
(63, '198609262015051001', '$2y$10$Dop3tOWrhabq2ponVIcDtOgIfeKFjOFywMgCBb93xzMEzvxXRFw/q', 'EKA SAPUTRA', NULL, 'dosen', NULL, 1, 0),
(64, '198609262015051002', '$2y$10$D6w7IY3LA7aMteQPr3Eq4.wlI/3AOrnc31X6Eog8GD6gxRtDpRMsa', 'EKA SAPUTRA', NULL, 'dosen', NULL, 1, 0),
(65, '198609262015051003', '$2y$10$sBCEF9TlBi66tWtRYiZGRO4QJVbu2A1lql78gm.pFIEFhE/sMLcyu', 'EKA SAPUTRA', NULL, 'dosen', NULL, 1, 0),
(66, '198609262015051004', '$2y$10$cSUeA3G64OhVWe5KMo8mwuka563EidQVOuMLJgYDtW8G.FjI0i8dy', 'EKA SAPUTRA', NULL, 'dosen', NULL, 1, 0),
(67, '198609262015051005', '$2y$10$avVm2aF6EHdbiIimbchf7.e7AvkbPnnnaknVH7rwHe0cfo6Pyke0.', 'EKA SAPUTRA', NULL, 'dosen', NULL, 1, 0),
(68, '198609262015051006', '$2y$10$HJPGk2/j1EUrWdIUaObl0uMstQeimAd9CgOWAshIWpPLRVSAYWs8W', 'EKA SAPUTRA', NULL, 'dosen', NULL, 1, 0),
(69, '198609262015051007', '$2y$10$GnMInaB3wXhrLUCagmtXhO/QG99LMHzd1xEAfIMKqFuI1UfaiP.Va', 'EKA SAPUTRA', NULL, 'dosen', NULL, 1, 0),
(70, '198609262015051008', '$2y$10$RdNE4U8FP2UPuTm3WznO4uzl6Vu8HjgTYJSeUrmF.zN.ukNcj4B.y', 'EKA SAPUTRA', NULL, 'dosen', NULL, 1, 0),
(71, '198609262015051010', '$2y$10$EJtStrkAVnnfETjO2D2Po.x1KuMY84WHamujycxmWhsnGex61g06G', 'EKA SAPUTRA', NULL, 'dosen', NULL, 1, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `arsip`
--
ALTER TABLE `arsip`
  ADD PRIMARY KEY (`idarsip`);

--
-- Indexes for table `dosen`
--
ALTER TABLE `dosen`
  ADD PRIMARY KEY (`iddosen`);

--
-- Indexes for table `mahasiswa`
--
ALTER TABLE `mahasiswa`
  ADD PRIMARY KEY (`idmahasiswa`);

--
-- Indexes for table `publikasi`
--
ALTER TABLE `publikasi`
  ADD PRIMARY KEY (`idpublikasi`);

--
-- Indexes for table `skripsi`
--
ALTER TABLE `skripsi`
  ADD PRIMARY KEY (`idskripsi`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`idusers`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `arsip`
--
ALTER TABLE `arsip`
  MODIFY `idarsip` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `dosen`
--
ALTER TABLE `dosen`
  MODIFY `iddosen` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `mahasiswa`
--
ALTER TABLE `mahasiswa`
  MODIFY `idmahasiswa` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `publikasi`
--
ALTER TABLE `publikasi`
  MODIFY `idpublikasi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `skripsi`
--
ALTER TABLE `skripsi`
  MODIFY `idskripsi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `idusers` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=72;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
