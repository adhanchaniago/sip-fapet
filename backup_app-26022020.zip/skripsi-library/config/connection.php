<?php
    $hostname   = "localhost";
    $username   = "root";
    $password   = "";
    $database   = "skripsi_library";

    $con = mysqli_connect($hostname, $username, $password, $database) or die (mysqli_error($con));
?>